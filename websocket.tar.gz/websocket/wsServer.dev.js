var app = require('http').createServer();
var io = require('socket.io')(app);
var http = require('https'); 
var mysql = require('mysql');

app.listen(8080);

var conn = mysql.createConnection({
    host: 'cdb-57ot9juu.cd.tencentcdb.com',
    port: 10114,
    user: 'root',
    database: 'movie',
    password: 'g00d_m1n'
});

theater = {};
app_id='wxe159625f94ea1bc6';
app_secret='574320aa28352686655a0edc7be31663'
login_url='https://api.weixin.qq.com/sns/jscode2session?';

function getToken(data) {
    return data;
}

io.on('connection',function (socket) {
    socket.on('init', function (dataofconn) {
	console.log('init:' + dataofconn.roomid);
	url=login_url + 'appid=' +  app_id + '&secret=' + app_secret + '&js_code=' + dataofconn.code + '&grant_type=authorization_code';
	socket.roomid = dataofconn.roomid;
	http.get(url, function(res){
	    var dataString="";
	    res.on("data",function(data){
	        dataString+=data;
	    });
	    res.on("end",function(){
		var dat = JSON.parse(dataString);
		if(theater[dataofconn.roomid] == undefined){
		    theater[dataofconn.roomid] = {};
		}
		else {
		    if(theater[dataofconn.roomid][dataofconn.token] != undefined) {
			theater[dataofconn.roomid][dataofconn.token].disconnect(true);
			delete theater[dataofconn.roomid][dataofconn.token];
		    }
		}
		var token = getToken(dat.openid);
		socket.token = dataofconn.token;
		socket.thumbnail = dataofconn.thumbnail;
		socket.currentTime = 0;
		socket.videourl = "";
		theater[dataofconn.roomid][dataofconn.token] = {};
		theater[dataofconn.roomid][dataofconn.token] = socket;
		theater[dataofconn.roomid][dataofconn.token].emit('connected', {msg: "connected", token: dataofconn.token});
		for(let element in theater[dataofconn.roomid]) {
            		theater[dataofconn.roomid][element].emit("mes", {thumbnail: socket.thumbnail, user: dataofconn.token, text:socket.token + "已进入房间", color: '#ffffff', time: -1.1, });
			theater[dataofconn.roomid][element].emit("realSyn");
			if(element != socket.token) {
			    theater[dataofconn.roomid][socket.token].emit("mes", {thumbnail: theater[dataofconn.roomid][element].thumbnail, user: element, text: element + "已进入房间", color: '#ffffff', time: -1.1, });
			}
        	}
		setTimeout(()=>{
		    var videourl = "";
                    var currentTime = 0;
		    for(let element in theater[dataofconn.roomid]) {
			if(theater[dataofconn.roomid][element].currentTime > currentTime){
			    currentTime = theater[dataofconn.roomid][element].currentTime;	
			    videourl = theater[dataofconn.roomid][element].videourl
            		}
        	    }
		    if(videourl != ""){
		        theater[dataofconn.roomid][dataofconn.token].emit("syn", {currentTime: currentTime + 4, videourl: videourl});
		    }
		}, 3000);
	    });
	});
    });
    
    socket.on("mes", function(data){
	for(let element in theater[data.roomid]) {
	    theater[data.roomid][element].emit("mes", {thumbnail: socket.thumbnail, user: data.token, text:data.text, color: data.color, time: data.time, });
	}
    });

    socket.on("realSyn", function(data){
	if(data.videourl != "") {
	    theater[data.roomid][data.token].currentTime = data.currentTime;
	    theater[data.roomid][data.token].videourl = data.videourl;
	}
    });

    socket.on('check2server', function (data) {
        for(let element in theater[data.roomid]) {
            if(data.token == element) {
		theater[data.roomid][element].emit('check2server', data);
	    }
	}
    });

    socket.on('play', function (data) {
        for(let element in theater[data.roomid]) {
	    if(data.token != element) {
                theater[data.roomid][element].emit("play", {currentTime:data.currentTime, videourl: data.videourl});
	    }
        }
    });

    socket.on('pause', function (data) {
        for(let element in theater[data.roomid]) {
            if(data.token != element) {
                theater[data.roomid][element].emit("pause", {currentTime:data.currentTime, videourl: data.videourl});
            }
        }
    });

    socket.on('syn', function (data) {
        for(let element in theater[data.roomid]) {
            if(data.token != element) {
                theater[data.roomid][element].emit("syn", {currentTime:data.currentTime, videourl: data.videourl});
            }
        }
    });

    socket.on('choosemovie', function(data) {
	var conn = mysql.createConnection({
	    host: 'cdb-57ot9juu.cd.tencentcdb.com',
	    port: 10114,
	    user: 'root',
	    database: 'movie',
	    password: 'g00d_m1n'
	});
	conn.query('select * from movielist', function(err, rows, fields) {
            if (err) {
                throw err
            }
            for(let element in theater[data.roomid]) {
                theater[data.roomid][element].emit("choosemovie", rows);
            }
        });
	conn.end(function(err){});
    });

    socket.on('selectone', function(data) {
            for(let element in theater[data.roomid]) {
                theater[data.roomid][element].emit("selectone", {data: data.data,  episode:data.episode});
		if(data.type == 1) {
                	theater[data.roomid][element].emit("mes", {thumbnail: socket.thumbnail, user: data.token, text: '选择了电影' + '《' + data.data.movie + '》' + '，请选择集数。', color: '#ffffff', time: -1, });
		}        

	   }
    });

    socket.on('voice', function(data){
            for(let element in theater[data.roomid]) {
                    theater[data.roomid][element].emit("voice", { thumbnail: socket.thumbnail, user: data.token, fileID:data.fileID, color: data.color, time: data.time, });
	   }	

    });

    socket.on('error', function (e) {
	console.log('error:' + e);
    });

    socket.on('chooseone', function(data) {
            for(let element in theater[data.roomid]) {
                theater[data.roomid][element].emit("chooseone", {code: data.code, episode:data.episode , format: data.format});
                theater[data.roomid][element].emit("mes", {thumbnail: socket.thumbnail, user: data.token, text: '播放《' + data.movie + '》', color: data.color, time: data.time, });
	    }
    });

    socket.on('closeall', function(data) {
            for(let element in theater[data.roomid]) {
                theater[data.roomid][element].emit("closeall");
		theater[data.roomid][element].disconnect(true);
		delete theater[data.roomid][element];
            }
	    delete theater[data.roomid];
    });

    socket.on('disconnect', () => {
        for(let element in theater[socket.roomid]) {
            theater[socket.roomid][element].emit("mes", {thumbnail: socket.thumbnail, user: socket.token, text:'离开了房间', color: '#ffffff', time: 0, });
        }
    });
});


console.log('server listening on 8080');
