var app = require('http').createServer();
var io = require('socket.io')(app);
var http = require('https'); 

app.listen(8080);

theater = {};
app_id='wxe159625f94ea1bc6';
app_secret='574320aa28352686655a0edc7be31663'
login_url='https://api.weixin.qq.com/sns/jscode2session?';

function getToken(data) {
    return data;
}

io.on('connection',function (socket) {
    socket.on('init', function (dataofconn) {
	console.log('init:' + dataofconn.roomid);
	url=login_url + 'appid=' +  app_id + '&secret=' + app_secret + '&js_code=' + dataofconn.code + '&grant_type=authorization_code';
	http.get(url, function(res){
	    var dataString="";
	    res.on("data",function(data){
	        dataString+=data;
	    });
	    res.on("end",function(){
		console.log(JSON.parse(dataString));
		var dat = JSON.parse(dataString);
		if(theater[dataofconn.roomid] == undefined){
		    theater[dataofconn.roomid] = {};
		}
		var token = getToken(dat.openid);
		theater[dataofconn.roomid][token] = {};
		theater[dataofconn.roomid][token] = socket;
		theater[dataofconn.roomid][token].emit('connected', {msg: "connected", token: token});
	    });
	});
    });
    
    socket.on("mes", function(data){
	console.log('mes:' + data.mes)
	for(let element in theater[data.roomid]) {
            console.log('send mes to ' + data.token);
	    theater[data.roomid][element].emit("mes", {user: data.token, text:data.mes, color: data.color, time: data.time, });
	}
    });

    socket.on('res', function (data) {
        console.log(data);
    });

    socket.on('play', function (data) {
	console.log('play:'+ data.currentTime);
        for(let element in theater[data.roomid]) {
	    if(data.token != element) {
		console.log('send play signal to ' + data.token);
                theater[data.roomid][element].emit("play", {currentTime:data.currentTime});
	    }
        }
    });

    socket.on('pause', function (data) {
	console.log('pause:' + data.currentTime);
        for(let element in theater[data.roomid]) {
            if(data.token != element) {
                console.log('send pause signal to ' + data.token);
                theater[data.roomid][element].emit("pause", {currentTime:data.currentTime});
            }
        }

        console.log(data);
    });

    socket.on('syn', function (data) {
	console.log('syn:' + data.currentTime);
        for(let element in theater[data.roomid]) {
            if(data.token != element) {
                console.log('send syn signal to ' + data.token);
                theater[data.roomid][element].emit("syn", {currentTime:data.currentTime});
            }
        }
        console.log(data);
    });

    socket.on('error', function (e) {
	console.log('error:' + e);
    })
});


console.log('server listening on 8080');
